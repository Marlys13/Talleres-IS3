from email import message
from multiprocessing import connection
import pika
from pika.exchange_type import ExchangeType

connection_parameters = pika.ConnectionParameters('localhost')
connection = pika.BlockingConnection(connection_parameters)
channel = connection.channel()
channel.exchange_declare(exchange='pubsub', exchange_type=ExchangeType.fanout)
mensaje = "Hola soy el productor "
channel.basic_publish(exchange='pubsub', routing_key='', body=mensaje)
print(f"mensaaje enviado: {mensaje}")
connection.close
