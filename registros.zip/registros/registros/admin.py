from django.contrib import admin
from .models import Registro

admin.site.register(Registro)