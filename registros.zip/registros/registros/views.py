from django.http import JsonResponse
from .models import Registro
from .serializers import RegistroSerializer

def registro_list(request):

    registros = Registro.objects.all()
    serializer = RegistroSerializer(registros, many=True)
    return JsonResponse(serializer.data, safe=False)
