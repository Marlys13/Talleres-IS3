from random import choices
from django.db import models

class Registro(models.Model):
    name = models.CharField(max_length=200)
    LANG = (
        ('EN', 'English'),
        ('FR', 'French'),
        ('ES', 'Spanish'),
    )
    lang = models.CharField(max_length=2, choices=LANG)


    def __str__(self):
        return self.name